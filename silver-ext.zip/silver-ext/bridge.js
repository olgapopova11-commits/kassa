// мост: страница Silver ↔ расширение
document.documentElement.dataset.silverExt = '1';
document.documentElement.dataset.silverExtV = chrome.runtime.getManifest().version;
window.addEventListener('message', e => {
  if(e.source !== window || !e.data || e.data.silverExt !== 'run') return;
  const { id, kind, key } = e.data;
  chrome.runtime.sendMessage({ kind, key }, r => window.postMessage(Object.assign({ silverExt:'done', id }, r || { ok:false, text:'нет ответа' }), '*'));
});
