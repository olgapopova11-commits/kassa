// код обновления — тот же, что в закладках Silver
function silverChinaSync(K){
  const SB = 'https://ottuadjdksxipfjytlyv.supabase.co/rest/v1/rpc/', AK = 'sb_publishable_OyN1810CuHrR9Ys0VTSExA_XY-nO7zo';
  const rpc = async (fn, body) => { const r = await fetch(SB + fn, { method:'POST', headers:{ 'content-type':'application/json', apikey:AK, authorization:'Bearer ' + AK }, body:JSON.stringify(body) }); const j = await r.json().catch(() => null); if(!r.ok) throw Error((j && (j.message || j.hint)) || ('Silver ' + r.status)); return j; };
  let b = document.getElementById('silver-cn');
  if(!b){ b = document.createElement('div'); b.id = 'silver-cn'; b.style.cssText = 'position:fixed;z-index:2147483647;left:50%;top:16px;transform:translateX(-50%);max-width:92vw;padding:12px 18px;border-radius:14px;background:#111;color:#fff;font:600 14px/1.4 -apple-system,system-ui,sans-serif;box-shadow:0 8px 30px rgba(0,0,0,.3)'; document.body.appendChild(b); }
  const say = t => { b.textContent = t; };
  const h = location.hostname, day = 864e5, LIMIT = Date.now() - 31 * day;   // только последний месяц
  const send = async (src, orders) => { const tot = { new:0, updated:0, items:0, linked:0 }; for(let i = 0; i < orders.length; i += 40){ const d = await rpc('po_ingest', { p_key:K, p_source:src, p:orders.slice(i, i + 40) }); for(const k in tot) tot[k] += +(d || {})[k] || 0; } return tot; };
  const done = (name, t) => say('Silver ✓ ' + name + ': новых заказов ' + t.new + ', обновлено ' + t.updated + (t.items ? ', позиций ' + t.items + ' (сразу связано с базой ' + t.linked + ')' : '') + '. Вкладку можно закрыть.');
  async function c1688(){
    if(!(window.lib && lib.mtop && lib.mtop.request)){ say('Silver: открываю страницу заказов 1688… Когда она загрузится, нажмите закладку ещё раз.'); location.href = 'https://trade.1688.com/order/buyer_order_list.htm'; return; }
    const ST = { waitsellersend:'等待卖家发货', waitbuyerreceive:'等待买家确认收货', waitbuyersign:'等待买家确认收货', send_goods_but_not_fund:'等待买家确认收货', confirm_goods:'已收货', confirm_goods_but_not_fund:'已收货', success:'交易成功', cancel:'交易关闭', terminated:'交易关闭' };
    const num = v => +(v && typeof v === 'object' ? (v.realAmount ?? v.calAmount) : v) || 0, yuan = v => Math.round(num(v)) / 100;
    const out = []; let old = false;
    for(let page = 1; page <= 8 && !old; page++){
      say('Silver: читаю заказы 1688, страница ' + page + '…');
      const r = await lib.mtop.request({ api:'mtop.1688.trading.dataline.service', v:'1.0', type:'POST', dataType:'json', valueType:'original', data:{ serviceId:'OrderListDataLineService.buyerOrderList', param:JSON.stringify({ page, pageSize:50 }) } });
      let x = r && r.data && r.data.data && r.data.data.result; if(typeof x === 'string') x = JSON.parse(x);
      const L = (x && x.data && x.data.data) || []; if(!L.length) break;
      for(const o of L){
        const t = Date.parse(String(o.gmtCreate).replace(' ', 'T') + '+08:00'); if(t < LIMIT){ old = true; continue; }
        if(o.status === 'waitbuyerpay') continue;   // ещё не оплачен — заберём, когда оплатите
        const qty = e => { let q = e.quantity; if(typeof q === 'string'){ try{ q = JSON.parse(q); }catch(_){ } } return num(q) || 1; };
        out.push({ no:String(o.idStr || o.id), seller:o.sellerInfo && o.sellerInfo.companyName, seller_login:o.sellerInfo && o.sellerInfo.loginId, ship:yuan(o.carriage), adj:yuan(o.adjustFee), status:ST[o.status] || o.statusLabel || o.status, created:o.gmtCreate, track:null,
          items:(o.orderEntries || []).map(e => { let sp = e.specInfo; if(typeof sp === 'string'){ try{ sp = JSON.parse(sp); }catch(_){ sp = null; } } const spec = ((sp && sp.specItems) || []).map(s => s.specValue).filter(Boolean).join(' / ');
            return { title:(e.productName || '') + (spec ? ': ' + spec : ''), price:yuan(e.actualUnitPrice || e.price), qty:qty(e), unit:e.unit || null, art:e.productNumber || null, offer:e.sourceId ? String(e.sourceId) : null, sku:e.skuId ? String(e.skuId) : null, sku_art:null }; }) });
      }
      if(x.data.pages && page >= x.data.pages) break;
    }
    say('Silver: отправляю ' + out.length + ' заказов…');
    done('Китай', await send('1688', out));
  }
  async function cAli(){
    if(h !== 'biz.alibaba.com'){ say('Silver: открываю страницу заказов Alibaba… Когда она загрузится, нажмите закладку ещё раз.'); location.href = 'https://biz.alibaba.com/order/list.htm'; return; }
    const ck = n => (document.cookie.match(new RegExp('(?:^|; )' + n + '=([^;]*)')) || [])[1] || '';
    const list = []; let old = false;
    for(let page = 1; page <= 10 && !old; page++){
      say('Silver: читаю заказы Alibaba, страница ' + page + '…');
      const q = { requests:{ simpleFilter:null, pagination:{ currentPage:page, pageSize:20 } }, pagination:{ currentPage:page, pageSize:20 }, responseModel:'V2', requestEnvironment:{ operator:{ role:'buyer' } } };
      const j = await fetch('/list/ajax/ta/mainv2.json?json=' + encodeURIComponent(JSON.stringify(q)) + '&ctoken=' + ck('ctoken') + '&_tb_token_=' + ck('_tb_token_'), { credentials:'include' }).then(r => r.json());
      const p = j && j.data && j.data.pageData; if(!p || !p.data || !p.data.length) break;
      for(const o of p.data){ if(Date.parse(o.baseInfo.createTime) < LIMIT) old = true; else list.push(o); }
      if(!p.pagination || page >= p.pagination.totalPage) break;
    }
    const L = list.filter(o => o.statusAction && o.statusAction.status && o.statusAction.status.name !== 'unpay');
    const known = new Set(await rpc('po_known', { p_key:K, p_source:'alibaba', p_nos:L.map(o => String(o.baseInfo.id)) }) || []);
    const out = []; let i = 0;
    for(const o of L){
      const no = String(o.baseInfo.id), st = o.statusAction.status.displayName || o.statusAction.status.name, pay = o.paymentInfo || {}, n = v => (v && +v.number) || 0;
      const base = { no, seller:o.seller && o.seller.companyName, created:o.baseInfo.createTime, status:st, track:null, ship:n(pay.shippingFeeAmount), fee:0, discount:0, items:[] };
      if(!known.has(no)){
        say('Silver: читаю состав нового заказа Alibaba ' + (++i) + '…');
        const t = await fetch('/ta/detail.htm?orderId=' + no, { credentials:'include' }).then(r => r.text());
        const a = t.indexOf('window["simpleTradeDetailVO"]'), z = t.indexOf('</script>', a);
        let vo = null; try{ vo = JSON.parse(t.slice(t.indexOf('=', a) + 1, z).trim().replace(/;$/, '')); }catch(_){ }
        const find = (x, d) => { if(!x || typeof x !== 'object' || d > 6) return null; if(Array.isArray(x.products) && x.products[0] && x.products[0].skuId !== undefined) return x.products; for(const v of Object.values(x)){ const r = find(v, d + 1); if(r) return r; } return null; };
        const P = find(vo, 0);
        if(P) base.items = P.map(e => ({ title:e.name, spec:e.sku || null, price:+((e.unitPriceAmountVO && e.unitPriceAmountVO.amount) || 0), qty:+e.quantity || 1, unit:e.unit && (e.unit.name || e.unit.code), offer:e.productId ? String(e.productId) : null, sku:e.skuId ? String(e.skuId) : null, photo:e.snapshotImage || null }));
        else (o.productInfo && o.productInfo.products || []).forEach(pr => (pr.skuList || []).forEach(s => base.items.push({ title:pr.name, spec:s.skuDescription || null, price:n(s.unitPrice), qty:n(s.quantity) || 1, unit:s.unit, offer:String(pr.id), sku:s.skuId ? String(s.skuId) : null, photo:s.imageUrl || pr.imageUrl })));
      }
      out.push(base);
    }
    say('Silver: отправляю ' + out.length + ' заказов…');
    done('Alibaba', await send('alibaba', out));
  }
  (/(^|\.)1688\.com$/.test(h) ? c1688() : /(^|\.)alibaba\.com$/.test(h) ? cAli() : Promise.resolve(say('Silver: откройте страницу заказов 1688 или Alibaba и нажмите закладку там.'))).catch(e => say('Silver: ошибка — ' + e.message));
}
function silverWiponSync(K){
  if(window.__ss){ window.__ss.run(); return; }
  const F = 'https://ottuadjdksxipfjytlyv.supabase.co/functions/v1/ingest?action=';
  const b = document.createElement('div'); b.id = 'silver-wu';
  b.style.cssText = 'position:fixed;right:12px;bottom:12px;z-index:99999;background:#1d2b4f;color:#fff;padding:8px 12px;border-radius:10px;font:13px sans-serif;box-shadow:0 4px 16px rgba(0,0,0,.3);max-width:420px';
  document.body.appendChild(b);
  const S = t => { t = ' ' + String(t || '').toLowerCase().replace(/ё/g, 'е').replace(/[_.,;:()"«»\-]+/g, ' ').replace(/\s+/g, ' ') + ' '; const W = '(?![а-яa-z])';
    if(new RegExp('(мун|moon)\\s*(а|a)' + W).test(t) || /(мун|moon)\s*алмат/.test(t)) return 6;
    if(/(мун|moon)\s*астан/.test(t) || new RegExp('(мун|moon)' + W).test(t)) return 7;
    if(/курмангаз/.test(t)) return 1; if(/толе\s*би/.test(t)) return 2; if(/гагарин/.test(t)) return 3; if(/республик/.test(t)) return 4; if(/достык/.test(t)) return 5; return null; };
  const day = x => new Date(x.getTime() + 18e6).toISOString().slice(0, 10);
  const L = k => { try{ return JSON.parse(localStorage.getItem(k) || 'null'); }catch(_){ return null; } }, P = (k, v) => { try{ localStorage.setItem(k, JSON.stringify(v)); }catch(_){} };
  const api = async p => { const tk = JSON.parse(localStorage.getItem('vuex')).user.token; const r = await fetch('https://api.wipon.kz' + p, { headers:{ Accept:'application/json', Authorization:'Bearer ' + tk } }); if(!r.ok) throw Error('Wipon ' + r.status); return r.json(); };
  const all = async p => { const out = []; let pg = 1, total = null; for(;;){ const j = await api(p + '&page=' + pg); out.push(...(j.data || [])); total = j.meta ? j.meta.total : null; if(!j.meta || pg >= j.meta.last_page) break; pg++; } return { rows:out, total }; };
  const post = async (a, st, rows) => { const r = await fetch(F + a, { method:'POST', headers:{ 'content-type':'application/json', 'x-ingest':K }, body:JSON.stringify({ store:+st, rows }) }); const j = await r.json(); if(j.error) throw Error(j.error); return j; };
  async function one(emp){
    const now = new Date(), rng = 'date_from=' + day(new Date(now - 2 * 864e5)) + 'T00:00:00%2B05:00&date_to=' + day(now) + 'T23:59:59%2B05:00&per_page=100';
    let ns = 0, nr = 0, nst = 0;
    const sales = (await all('/v1/employee/' + emp + '/sale?' + rng)).rows, by = {};
    for(const s of sales){ const st = S(s.stock && s.stock.name) || S(s.employee_name); if(!st) continue; const pay = (s.payments || []).map(x => x.name).join(',');
      for(const it of s.item_sale || []){ const q = +it.quantity || 1; (by[st] = by[st] || []).push({ no:String(s.id), emp:s.employee_name, at:s.created_at, pay, name:it.item && it.item.title, cat:it.item && it.item.item_category_name, bc:it.item && it.item.barcode, qty:q, total:Math.round((+it.price || +it.selling_price || 0) * q - (+it.discount_amount || 0)), ret:false }); } }
    for(const st in by) ns += +(await post('wipon_sales', st, by[st])).new || 0;
    const refs = (await all('/v1/employee/' + emp + '/refund?' + rng)).rows, rb = {};
    for(const r of refs){ const st = S(typeof r.stock === 'string' ? r.stock : r.stock && r.stock.name) || S(r.employee_name); if(!st) continue;
      (rb[st] = rb[st] || []).push({ id:r.id, at:r.created_at, emp:r.employee_name, pay:r.payment_name || '', amount:+r.amount, items:(r.item_refund || []).map(i => ({ bc:i.item && i.item.barcode, name:i.item && i.item.title, qty:+i.quantity, total:+i.sum })) }); }
    for(const st in rb) nr += +(await post('wipon_refunds', st, rb[st])).new || 0;
    const lk = 'silver_stock_at_' + emp;
    if(Date.now() - (L(lk) || 0) > 36e5){
      const stocks = (await api('/v2/employee/' + emp + '/stock')).data || [];
      for(const k of stocks){ const st = S(k.name); if(!st) continue;
        const x = await all('/v2/employee/' + emp + '/item?type=0&stock_id=' + k.id + '&per_page=250&positive_balance=1&is_weighted=0&trashed=0&only_parents=1');
        if(x.total != null && x.rows.length < x.total) continue; // загрузилось не всё — остатки не трогаем
        const rows = x.rows.filter(i => i.barcode).map(i => ({ bc:i.barcode, name:i.title, qty:+i.quantity, cost:+i.previous_purchase_price || null, price:+i.selling_price || null, cat:i.item_category_name }));
        if(rows.length){ await post('wipon_stock', st, rows); nst++; } }
      try{ // смены Wipon за 3 дня → Silver (для остатка наличных в кассе)
        const d3 = day(new Date(now - 3 * 864e5)), sh = await api('/v1/employee/' + emp + '/shift?per_page=100&page=1&date_from=' + d3 + 'T00:00:00%2B05:00&date_to=' + day(now) + 'T23:59:59%2B05:00');
        const srows = (sh.data || []).map(r => { const x = JSON.parse(JSON.stringify(r)); if(x.employee && typeof x.employee === 'object') delete x.employee.company; if(x.stock && typeof x.stock === 'object') x.stock = { id:x.stock.id, name:x.stock.name }; return x; });
        if(srows.length) await fetch('https://ottuadjdksxipfjytlyv.supabase.co/functions/v1/wipon_hist', { method:'POST', headers:{ 'content-type':'application/json', 'x-ingest':K }, body:JSON.stringify({ kind:'shift', emp, rows:srows }) });
      }catch(_){ /* смены не критичны */ }
      P(lk, Date.now()); }
    return [ns, nr, nst];
  }
  async function run(){
    try{
      b.textContent = 'Silver: обновляем данные из Wipon…';
      const cur = JSON.parse(localStorage.getItem('vuex')).employee.item.id, E = L('silver_wipon_emps') || [];
      if(!E.includes(cur)){ E.push(cur); P('silver_wipon_emps', E); }
      let t = [0, 0, 0]; const bad = [];
      for(const e of E){ try{ const r = await one(e); t = t.map((x, i) => x + r[i]); }catch(err){ bad.push(err.message); } }
      b.textContent = 'Silver ✓ ' + new Date().toLocaleTimeString('ru-RU', { hour:'2-digit', minute:'2-digit' }) + ' · новых чеков: ' + t[0] + ' · возвратов: ' + t[1] + (t[2] ? ' · остатки обновлены (' + t[2] + ' скл.)' : '') + ' · кабинетов ИП: ' + E.length + (bad.length ? ' · ошибка: ' + bad[0] : '') + ' · следующая через 15 мин';
    }catch(e){ b.textContent = 'Silver: ошибка — ' + e.message + ' (повторим через 15 мин)'; }
  }
  // новый режим: передаём сеанс Wipon серверу Silver — дальше он обновляет сам, вкладку можно закрыть
  const SRV = 'https://ottuadjdksxipfjytlyv.supabase.co/functions/v1/wipon_srv';
  const call = async body => { const r = await fetch(SRV, { method:'POST', headers:{ 'content-type':'application/json', 'x-ingest':K }, body:JSON.stringify(body) }); const j = await r.json().catch(() => ({})); if(!r.ok || j.error) throw Error(j.error || ('Silver ' + r.status)); return j; };
  async function srv(){
    b.textContent = 'Silver: передаём сеанс Wipon серверу…';
    const v = JSON.parse(localStorage.getItem('vuex')), cur = v.employee.item.id, E = L('silver_wipon_emps') || [];
    if(!E.includes(cur)){ E.push(cur); P('silver_wipon_emps', E); }
    const it = (v.employee && v.employee.item) || {}, co = String((it.company && (it.company.name || it.company.title)) || it.company_name || (v.company && (v.company.name || v.company.title)) || '');
    const s = await call({ action:'set_token', token:v.user.token, emps:E, cos:{ [cur]: co } });
    b.textContent = 'Silver: сеанс передан (кабинетов ИП: ' + s.cabinets + '), загружаем данные…';
    let p = null; try{ p = await call({ action:'pull_now' }); }catch(_){ /* сервер повторит сам через 15 мин */ }
    b.textContent = 'Silver ✓ будет обновляться сам каждые 15 минут — вкладку можно закрыть' + (p && p.sales != null ? ' · новых чеков: ' + p.sales + ' · возвратов: ' + p.refunds : '') + ' · переключитесь по очереди на каждое ИП (включая ИП «Луна») и нажмите закладку ещё раз';
  }
  srv().then(() => { window.__ss = { run: () => srv().catch(e => { b.textContent = 'Silver: ' + e.message; }) }; })
    .catch(e => { b.textContent = 'Silver: сервер не принял сеанс (' + e.message + ') — обновляем из этой вкладки'; window.__ss = { run }; run(); setInterval(run, 9e5); });
}
