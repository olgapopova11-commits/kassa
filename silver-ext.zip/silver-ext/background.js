importScripts('sync.js');
const sleep = ms => new Promise(r => setTimeout(r, ms));
const JOBS = {
  china:   { url:'https://trade.1688.com/order/buyer_order_list.htm', fn:silverChinaSync, box:'silver-cn', who:'1688',
             ready:() => !!(window.lib && lib.mtop && lib.mtop.request) && !/login/.test(location.hostname) },
  alibaba: { url:'https://biz.alibaba.com/order/list.htm', fn:silverChinaSync, box:'silver-cn', who:'Alibaba',
             ready:() => location.hostname === 'biz.alibaba.com' && document.readyState === 'complete' },
  wipon:   { url:'https://console.wipon.kz/', fn:silverWiponSync, box:'silver-wu', who:'Wipon',
             ready:() => { try{ return !!JSON.parse(localStorage.getItem('vuex')).user.token; }catch(_){ return false; } } }
};
async function exec(tabId, func, args){ try{ const [r] = await chrome.scripting.executeScript({ target:{ tabId }, world:'MAIN', func, args:args || [] }); return r && r.result; }catch(_){ return undefined; } }
// рабочая база Google: открываем таблицу под входом Ольги и читаем лист как CSV (в таблице ничего не меняется)
async function runSheet(key){
  const id = String(key && key.id || '').replace(/[^\w-]/g, ''), gid = String(key && key.gid || '').replace(/\D/g, ''), range = String(key && key.range || '').replace(/[^A-Z0-9:]/g, '');
  if(!id) return { ok:false, text:'нет id таблицы' };
  const tab = await chrome.tabs.create({ url:'https://docs.google.com/spreadsheets/d/' + id + '/edit#gid=' + gid, active:false });
  try{
    let ok = false;
    for(let i = 0; i < 60 && !ok; i++){ await sleep(500); ok = await exec(tab.id, () => location.hostname === 'docs.google.com' && /\/spreadsheets\/d\//.test(location.pathname) && document.readyState === 'complete'); }
    if(!ok){ await chrome.tabs.update(tab.id, { active:true }); return { ok:false, keep:true, text:'Войдите в Google в открывшейся вкладке и нажмите «Обновить» ещё раз' }; }
    const r = await exec(tab.id, async (id, gid, range) => { try{ const x = await fetch('/spreadsheets/d/' + id + '/export?format=csv&gid=' + gid + (range ? '&range=' + range : ''), { credentials:'include' });
      const t = await x.text(); return { s:x.status, ct:x.headers.get('content-type') || '', t }; }catch(e){ return { s:0, t:String(e) }; } }, [id, gid, range]);
    if(!r || r.s !== 200 || !/csv/.test(r.ct || '')) return { ok:false, text:'Рабочая база не открылась (' + (r && r.s) + ') — проверьте доступ к таблице' };
    return { ok:true, text:'Рабочая база прочитана', csv:r.t };
  }finally{ try{ const t = await chrome.tabs.get(tab.id); if(!t.active) await chrome.tabs.remove(tab.id); }catch(_){ } }
}
async function run({ kind, key }){
  if(kind === 'sheet') return runSheet(key);
  const J = JOBS[kind]; if(!J) return { ok:false, text:'неизвестная команда' };
  const tab = await chrome.tabs.create({ url:J.url, active:false });
  try{
    let ok = false;
    for(let i = 0; i < 60 && !ok; i++){ await sleep(500); ok = await exec(tab.id, J.ready); }
    if(!ok){ await chrome.tabs.update(tab.id, { active:true }); return { ok:false, keep:true, text:'Войдите в ' + J.who + ' в открывшейся вкладке и нажмите «Обновить» ещё раз' }; }
    // свежий код с сайта Silver (правки без переустановки расширения); если сайт недоступен — встроенный
    const fresh = await exec(tab.id, (src, kind, key) => new Promise(res => { const s = document.createElement('script'); s.src = src + '?v=' + Date.now();
      s.onload = () => { try{ window.__silverSync[kind](key); res(true); }catch(_){ res(false); } }; s.onerror = () => res(false); (document.head || document.documentElement).appendChild(s); }),
      ['https://sunshinesilver.kz/ext-sync.js', kind, key]);
    if(!fresh) await exec(tab.id, J.fn, [key]);
    for(let i = 0; i < 420; i++){
      await sleep(1000);
      const t = (await exec(tab.id, id => { const e = document.getElementById(id); return e ? e.textContent : ''; }, [J.box])) || '';
      if(/✓/.test(t)) return { ok:true, text:t };
      if(/ошибка|не принял|откройте|устарела/i.test(t)) return { ok:false, text:t };
    }
    return { ok:false, text:J.who + ': не дождалась ответа' };
  }finally{
    try{ const t = await chrome.tabs.get(tab.id); if(!t.active) await chrome.tabs.remove(tab.id); }catch(_){ }
  }
}
chrome.runtime.onMessage.addListener((m, s, reply) => { run(m).then(reply, e => reply({ ok:false, text:String(e && e.message || e) })); return true; });
