importScripts('sync.js');
const sleep = ms => new Promise(r => setTimeout(r, ms));
const JOBS = {
  china:   { url:'https://trade.1688.com/order/buyer_order_list.htm', fn:silverChinaSync, box:'silver-cn', who:'1688',
             ready:() => !!(window.lib && lib.mtop && lib.mtop.request) && !/login/.test(location.hostname) },
  alibaba: { url:'https://biz.alibaba.com/order/list.htm', fn:silverChinaSync, box:'silver-cn', who:'Alibaba',
             ready:() => location.hostname === 'biz.alibaba.com' && document.readyState === 'complete' },
  wipon:   { url:'https://console.wipon.kz/', fn:silverWiponSync, box:'silver-wu', who:'Wipon',
             ready:() => { try{ return !!JSON.parse(localStorage.getItem('vuex')).user.token; }catch(_){ return false; } } }
};
async function exec(tabId, func, args){ try{ const [r] = await chrome.scripting.executeScript({ target:{ tabId }, world:'MAIN', func, args:args || [] }); return r && r.result; }catch(_){ return undefined; } }
// рабочая база Google: читаем лист как CSV под входом Ольги в Google (все строки, без учёта фильтра; в таблице ничего не меняется)
async function runSheet(key){
  const id = String(key && key.id || '').replace(/[^\w-]/g, ''), gid = String(key && key.gid || '').replace(/\D/g, ''), range = String(key && key.range || '').replace(/[^A-Z0-9:]/g, '');
  if(!id) return { ok:false, text:'нет id таблицы' };
  try{
    const x = await fetch('https://docs.google.com/spreadsheets/d/' + id + '/export?format=csv&gid=' + gid + (range ? '&range=' + range : ''), { credentials:'include' });
    const t = await x.text(), ct = x.headers.get('content-type') || '';
    if(x.ok && /csv/.test(ct)) return { ok:true, text:'Рабочая база прочитана', csv:t };
    if(/accounts\.google\.com/.test(x.url) || /html/.test(ct)){ await chrome.tabs.create({ url:'https://docs.google.com/spreadsheets/d/' + id + '/edit', active:true }); return { ok:false, keep:true, text:'Войдите в Google в открывшейся вкладке и нажмите «Обновить» ещё раз' }; }
    return { ok:false, text:'Рабочая база не открылась (' + x.status + ')' };
  }catch(e){ return { ok:false, text:'Рабочая база: ' + String(e && e.message || e) }; }
}
async function run({ kind, key }){
  if(kind === 'sheet') return runSheet(key);
  const J = JOBS[kind]; if(!J) return { ok:false, text:'неизвестная команда' };
  const tab = await chrome.tabs.create({ url:J.url, active:false });
  try{
    let ok = false;
    for(let i = 0; i < 60 && !ok; i++){ await sleep(500); ok = await exec(tab.id, J.ready); }
    if(!ok){ await chrome.tabs.update(tab.id, { active:true }); return { ok:false, keep:true, text:'Войдите в ' + J.who + ' в открывшейся вкладке и нажмите «Обновить» ещё раз' }; }
    // свежий код с сайта Silver (правки без переустановки расширения); если сайт недоступен — встроенный
    const fresh = await exec(tab.id, (src, kind, key) => new Promise(res => { const s = document.createElement('script'); s.src = src + '?v=' + Date.now();
      s.onload = () => { try{ window.__silverSync[kind](key); res(true); }catch(_){ res(false); } }; s.onerror = () => res(false); (document.head || document.documentElement).appendChild(s); }),
      ['https://sunshinesilver.kz/ext-sync.js', kind, key]);
    if(!fresh) await exec(tab.id, J.fn, [key]);
    for(let i = 0; i < 420; i++){
      await sleep(1000);
      const t = (await exec(tab.id, id => { const e = document.getElementById(id); return e ? e.textContent : ''; }, [J.box])) || '';
      if(/✓/.test(t)) return { ok:true, text:t };
      if(/ошибка|не принял|откройте|устарела/i.test(t)) return { ok:false, text:t };
    }
    return { ok:false, text:J.who + ': не дождалась ответа' };
  }finally{
    try{ const t = await chrome.tabs.get(tab.id); if(!t.active) await chrome.tabs.remove(tab.id); }catch(_){ }
  }
}
chrome.runtime.onMessage.addListener((m, s, reply) => { run(m).then(reply, e => reply({ ok:false, text:String(e && e.message || e) })); return true; });
